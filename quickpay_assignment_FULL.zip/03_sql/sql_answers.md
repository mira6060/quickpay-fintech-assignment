# SQL Answers

## Q1
### Query
```sql
SELECT
    status,
    COUNT(*) AS transaction_count,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 2) AS percentage
FROM cleaned_transactions
GROUP BY status
ORDER BY transaction_count DESC;
```
### Result Summary
The transactions are distributed across 5 statuses. Chargebacks are the most frequent (107 transactions, 22.29%), followed by refunded (98, 20.42%) and captured (98, 20.42%), then pending (89, 18.54%) and failed (88, 18.33%). The near-equal distribution across statuses suggests the sample is balanced across transaction outcomes.

---

## Q2
### Query
```sql
SELECT
    merchant_name,
    COUNT(*) AS total_transactions,
    ROUND(SUM(amount_usd), 2) AS captured_gmv_usd
FROM cleaned_transactions
WHERE status = 'captured'
GROUP BY merchant_name
ORDER BY captured_gmv_usd DESC;
```
### Result Summary
Razorpay leads captured GMV at $50,331.28 (12 transactions), followed by Stripe Ltd at $46,980.57 (14 transactions). The top two merchants together account for over 50% of all captured GMV, indicating heavy concentration at the top.

---

## Q3
### Query
```sql
SELECT
    merchant_name,
    ROUND(SUM(amount_usd), 2) AS captured_gmv_usd,
    COUNT(*) AS captured_transactions
FROM cleaned_transactions
WHERE status = 'captured'
GROUP BY merchant_name
ORDER BY captured_gmv_usd DESC
LIMIT 10;
```
### Result Summary
All 8 merchants are shown since there are only 8 in the dataset. Razorpay ($50,331) and Stripe Ltd ($46,980) are clear leaders. Shopify Inc is at the bottom with $7,323 in captured GMV despite 9 transactions, suggesting lower average transaction values.

---

## Q4
### Query
```sql
SELECT
    transaction_date,
    ROUND(SUM(amount_usd), 2) AS daily_gmv_usd,
    COUNT(*) AS total_transactions,
    SUM(CASE WHEN status = 'captured' THEN 1 ELSE 0 END) AS successful_transactions,
    ROUND(SUM(CASE WHEN status = 'captured' THEN amount_usd ELSE 0 END), 2) AS captured_gmv_usd
FROM cleaned_transactions
GROUP BY transaction_date
ORDER BY transaction_date;
```
### Result Summary
Daily GMV varies significantly — from as low as $292 on one day to over $12,000 on another. Most days have 1–4 transactions. Successful (captured) transactions are unevenly distributed, with many days recording 0 captured transactions. The daily data can be used for trend analysis and anomaly detection.

---

## Q5
### Query
```sql
SELECT
    merchant_name,
    COUNT(*) AS total_transactions,
    SUM(CASE WHEN status = 'chargeback' THEN 1 ELSE 0 END) AS chargeback_count,
    ROUND(
        SUM(CASE WHEN status = 'chargeback' THEN 1 ELSE 0 END) * 100.0 / COUNT(*),
        2
    ) AS chargeback_ratio_pct
FROM cleaned_transactions
GROUP BY merchant_name
HAVING chargeback_ratio_pct > 1
ORDER BY chargeback_ratio_pct DESC;
```
### Result Summary
All 8 merchants exceed the 1% chargeback threshold. PayU India has the highest chargeback ratio at 33.87% (21 chargebacks out of 62 transactions), followed by Klarna AB at 32.26%. This is a serious concern — merchants with chargeback rates above 2% are typically flagged by card networks. All merchants here need immediate review.

---

## Q6
### Query
```sql
SELECT
    region,
    COUNT(*) AS transaction_count,
    ROUND(AVG(risk_score), 2) AS avg_risk_score
FROM cleaned_transactions
WHERE risk_score IS NOT NULL
GROUP BY region
HAVING avg_risk_score > 50 AND transaction_count > 20
ORDER BY avg_risk_score DESC;
```
### Result Summary
All three regions (EU, US, APAC) have average risk scores above 50 and more than 20 transactions. EU has the highest average risk score (55.22) with 144 transactions, followed by US (54.87, 155 transactions) and APAC (53.72, 172 transactions). All regions require active risk monitoring.

---

## Q7
### Query
```sql
SELECT
    user_id,
    transaction_date,
    COUNT(*) AS failed_or_chargeback_count
FROM cleaned_transactions
WHERE status IN ('failed', 'chargeback')
GROUP BY user_id, transaction_date
HAVING failed_or_chargeback_count >= 3
ORDER BY failed_or_chargeback_count DESC, transaction_date;
```
### Result Summary
No users had 3 or more failed/chargeback transactions on a single day in this dataset. This is a positive finding — there are no obvious fraud patterns involving repeated failures by the same user on the same day. This query would be valuable for ongoing fraud monitoring in a live environment.

---

## Q8
### Query
```sql
SELECT
    merchant_name,
    COUNT(*) AS chargeback_count,
    COUNT(DISTINCT user_id) AS unique_affected_users,
    ROUND(SUM(amount_usd), 2) AS total_chargeback_amount_usd,
    ROUND(AVG(amount_usd), 2) AS avg_chargeback_amount_usd
FROM cleaned_transactions
WHERE status = 'chargeback'
GROUP BY merchant_name
ORDER BY chargeback_count DESC;
```
### Result Summary
PayU India has the most chargebacks (21) affecting 20 unique users, with a total chargeback exposure of $69,389. Adyen NV, while having fewer chargebacks (13), has a very high total amount at $51,259, indicating large-value transactions are being disputed. Stripe Ltd has the fewest chargebacks (9) with $16,651 at risk. Total chargeback exposure across all merchants is approximately $244,143.
