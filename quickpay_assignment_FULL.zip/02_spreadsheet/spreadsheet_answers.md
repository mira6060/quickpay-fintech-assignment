# Spreadsheet Answers

## Cleaning Steps

The following cleaning steps were applied to `transactions_raw.csv`:

1. **Removed null/missing rows**: Rows missing critical fields (transaction_id, merchant_name, transaction_date, amount, status) were dropped. A total of 20 rows were removed, resulting in 480 clean records.
2. **Standardized merchant names**: All variations of merchant names (uppercase, lowercase, mixed case) were mapped to their canonical form using a lookup dictionary (e.g., "SHOPIFY INC", "shopify inc" → "Shopify Inc").
3. **Standardized date formats**: Multiple date formats (%Y-%m-%d, %d/%m/%Y, %m-%d-%Y, %d-%b-%Y) were parsed and converted to a single standard format: YYYY-MM-DD.
4. **Standardized status values**: All case variations (Captured, CAPTURED, captured) were normalized to lowercase (captured, failed, pending, chargeback, refunded).
5. **Standardized risk scores**: Text labels (low, medium, high) were mapped to numeric values (25, 50, 75). Invalid entries (N/A, blank) were replaced with the column median.
6. **Standardized gateway regions**: Variations like "us", "United States", "US" were all mapped to "US"; "Europe"/"eu" → "EU"; "Asia Pacific"/"apac" → "APAC".
7. **Cleaned amount field**: Converted to numeric, removed non-numeric entries.
8. **Standardized currency codes**: Trimmed whitespace and converted to uppercase.

## Standardization Rules

| Field | Raw Values | Standardized To |
|---|---|---|
| merchant_name | SHOPIFY INC, shopify inc | Shopify Inc |
| status | Captured, CAPTURED | captured |
| region | us, United States | US |
| region | eu, Europe | EU |
| region | apac, Asia Pacific | APAC |
| risk_score | low, medium, high | 25, 50, 75 |
| transaction_date | Multiple formats | YYYY-MM-DD |
| currency | lowercase, spaces | Uppercase, trimmed |

## Lookup and Enrichment Logic

1. **Currency to USD Conversion**: Each transaction's `amount` was multiplied by the corresponding `rate_to_usd` from `exchange_rates.csv` using a VLOOKUP/merge on the `currency` field. This created the `amount_usd` column.

2. **Merchant Enrichment**: The cleaned `merchant_name` was used to join `merchant_master.csv`, adding `merchant_id`, `category`, and `contract_value` to each transaction.

3. **High Value Flag Logic**:
   - `high_value_flag = 1` if: region = APAC AND amount_usd > 5000
   - `high_value_flag = 1` if: region = EU AND amount_usd > 6000
   - `high_value_flag = 1` if: region = US AND amount_usd > 7000
   - Otherwise = 0

4. **High Risk Flag Logic**:
   - `high_risk_flag = 1` if: risk_score >= 70
   - `high_risk_flag = 1` if: status contains "chargeback"
   - Otherwise = 0

## Final Answers

| Metric | Value |
|---|---|
| Total raw rows | 500 |
| Total cleaned rows | 480 |
| Invalid or missing rows handled | 20 |
| Top region by GMV | APAC |
| Number of high value transactions | 47 |
| Number of high risk transactions | 210 |
| Top merchant by captured GMV | Razorpay |

## Formula Samples

**Amount USD Conversion (Excel formula):**
```
=IF(ISBLANK(F2), "", VLOOKUP(F2, ExchangeRates!$A:$B, 2, 0) * E2)
```

**High Value Flag (Excel formula):**
```
=IF(OR(AND(I2="APAC", K2>5000), AND(I2="EU", K2>6000), AND(I2="US", K2>7000)), 1, 0)
```

**High Risk Flag (Excel formula):**
```
=IF(OR(J2>=70, ISNUMBER(SEARCH("chargeback", H2))), 1, 0)
```

**Total Captured GMV by Merchant (Excel formula):**
```
=SUMIFS(K:K, C:C, "Razorpay", H:H, "captured")
```

**Chargeback Ratio (Excel formula):**
```
=COUNTIFS(C:C, A2, H:H, "chargeback") / COUNTIF(C:C, A2)
```
